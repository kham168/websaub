import{_ as e}from"./DCg5IV2c.js";const n={};function r(c,t){return null}const o=e(n,[["render",r]]);export{o as default};
