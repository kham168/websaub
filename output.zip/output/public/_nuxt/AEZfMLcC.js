const n=t=>{const r=typeof t=="string"?parseFloat(t):t;return isNaN(r)?"-":new Intl.NumberFormat("lo-LA",{minimumFractionDigits:0}).format(r)};export{n as f};
